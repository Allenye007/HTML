/*
* 配置信息
**/

+function(window) {
    requirejs.config({
        urlArgs: 'v=' + new Date().getTime(),
        baseUrl: 'js/',
        paths: {
            '$': 'jquery-3.3.1.min',
            '_': 'underscore-min',
            'ELEMENT': 'element-ui/index'
        },
        // 模块处理, 处理不规范的模块
        shim: {
            '$': {
                deps: [],
                init: function(){
                    return window.jQuery.noConflict();
                }
            },
            '_': {
                deps: [],
                init: function(){
                    return window._.noConflict();
                }
            },
        },
        // 模块依赖
        map: {
            '*' : {
                // 处理 css 文件
                css: 'css',
                // 加载文本
                text : 'text',
            }
        },
    });
    define('_vue', ['./js/vue.js'], function (Vue) {
        return Vue;
    });
    // 注入全局的依赖
    define('vue', ['_vue', 'ELEMENT', 'drag'], function (Vue, ELEMENT) {
        require(['css!element-ui/index.css']);
        Vue.use(ELEMENT);
        return Vue;
    });
}(window);
