// 
require(['vue', '$', '_', 'select'], function(Vue, $, _, select){
    new Vue({
        el: '#app',
        data: {
            keys: []
        },
        components: {
            'more-select': select
        },
        computed: {
            apiSever: function () {
                return {
                    getSelectList: this.getSelectList
                }
            }
        },
        created: function () {

        },
        methods: {
            change: function(data) {
                console.log(data);
            },
            getSelectList: function() {
                return [
                    // 第一层
                    [
                        {
                            id: 1, // 当前元素ID
                            name: '北京', // 名称
                            pid: 0, // 父ID
                            isHaveSon: true, // 表示是否有下一级数据
                        },
                        {
                            id: 2, // 当前元素ID
                            name: '重庆', // 名称
                            pid: 0, // 父ID
                            isHaveSon: true // 表示是否有下一级数据
                        }
                    ],
                    // 第二层
                    [
                        {
                            id: 3, // 当前元素ID
                            name: '朝阳区', // 名称
                            pid: 1, // 父ID [父级为北京]
                            isHaveSon: false // 表示是否有下一级数据
                        },
                        {
                            id: 4, // 当前元素ID
                            name: '海淀区', // 名称
                            pid: 1, // 父ID [父级为北京]
                            isHaveSon: false // 表示是否有下一级数据
                        },

                        {
                            id: 5, // 当前元素ID
                            name: '渝中区', // 名称
                            pid: 2, // 父ID [父级为重庆]
                            isHaveSon: false // 表示是否有下一级数据
                        },
                        {
                            id: 6, // 当前元素ID
                            name: '沙坪坝区', // 名称
                            pid: 2, // 父ID [父级为重庆]
                            isHaveSon: false // 表示是否有下一级数据
                        },
                    ]
                ];
            }
        }
    })
});