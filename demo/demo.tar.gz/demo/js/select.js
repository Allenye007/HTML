
define(['DB', '_', 'text!/template/select.html'], function(DB, _, template) {
    require(['css!/css/select.css']);
    function createDB (alias, key, ref) {
        var tableName = _.uniqueId('table');
        if (ref) {
            return new DB(tableName, alias, key, ref);
        } else {
            return new DB(tableName);
        }
    }

    function App () {
        return {
            template: template,
            data() {
                return {
                    list: [], // 列表数据
                    checkList: this.keys || [], // 选中的数据
                    showSelect: [this.firstid],
                    searchVal: '', // 搜索内容
                    indeterminate: {} // 半选状态
                };
            },
            watch: {
            },
            props: {
                // 当前元素的标识
                foreignKey: {
                    type: String,
                    default: 'id'
                },
                // 与父级的关系
                foreignAlias: {
                    type: String,
                    default: 'parent_id'
                },
                keys: {
                    type: Array,
                    default () {
                        return [];
                    }
                },
                value: {
                    type: Array,
                    default () {
                        return [];
                    }
                },
                // 名称
                name: {
                    type: String,
                    required: true
                },
                selectTitle: {
                    type: String,
                    required: false,
                    default: '',
                },
                previewTitle: {
                    type: String,
                    required: false,
                    default: '',
                },
                // 第一层ID
                firstid: {
                    type: [String, Number],
                    default: function () {
                        return 0;
                    }
                },
                server: {
                    type: Object,
                    required: true,
                },
                preview: {
                    type: Boolean,
                    default: function () {
                        return false;
                    }
                }
            },
            computed: {
            },
            async created() {
                var self = this;
                var checkList = [].concat(this.$data.checkList);
                try {
                    let data = await this.getList({
                        index: 0 // 请求第一层数据
                    });
                    for (let i = 0, size = data.length; i < size; i++) {
                        // 根据数据创建 db 对象
                        if (!this.$data.list[i]) {
                            if (i > 0) {
                                this.$data.list[i] = createDB(this.foreignAlias, this.foreignKey, this.$data.list[i - 1]);
                            } else {
                                this.$data.list[i] = createDB();
                            }
                        }
                        // 创建存储复选框选中数据
                        if (!checkList[i]) {
                            checkList[i] = [];
                        }
                        this.$data.list[i].insert(data[i]);
                    }
                } catch (e) {
                    /* eslint-disable no-console */
                    console.log(e);
                }
                Object.assign(this.$data, {
                    checkList: checkList,
                });
                // 数据准备好
                setTimeout(function(){
                    self.$emit('onload');
                });
            },
            mounted() {
            },
            beforeUpdate() {
            },
            updated() {
            },
            methods: {
                // 设置默认选中
                setAutoChecked: function(autodata) {
                    var indeterminate = {};
                    autodata = _.flatten([].concat(autodata));
                    let checkList = [].concat(this.$data.checkList);
                    var foreignAlias = this.foreignAlias;
                    var foreignKey = this.foreignKey;
                    var tempKey = [];
                    _.each(this.$data.list, function(data, i){
                        _.each(data.select(), function(item){
                            if (item) {
                                // 如果 foreignKey 如果在默认选中数据中
                                if (autodata.includes(item[foreignKey])) {
                                    // 设置为选中状态
                                    checkList[i].push(item[foreignKey]);
                                    autodata.push(item[foreignKey]);
                                    tempKey.push({
                                        index: i,
                                        key: item[foreignKey]
                                    });
                                }
                                // 如果 foreignAlias 被选中了
                                else if (autodata.includes(item[foreignAlias])) {
                                    // 设置为选中状态
                                    checkList[i].push(item[foreignKey]);
                                    autodata.push(item[foreignKey]);
                                }
                            }
                        });
                    });

                    // 处理半选状态
                    for(var index = tempKey.length - 1; index >= 0; index--) {
                        var item = tempKey[index];
                        _.each(this.getParent(item['index'], item['key']), function(tmp){
                            if(tmp[foreignKey] !== item['key']) {
                                indeterminate[tmp[foreignKey]] = true;
                            }
                        });
                    }
                    Object.assign(this.$data, {
                        checkList: checkList,
                        indeterminate: indeterminate
                    });
                    this.syncData();
                },
                clearPreview: function(){
                    var checkList = [].concat(this.$data.checkList);
                    var array = checkList.map(() => []);
                    this.$data.checkList = array;
                    this.syncData();
                },
                // 删除元素(对某一个复选框做取消选中处理)
                removeElement (index, key) {
                    if (/^[0-9]+$/.test(key)) {
                        key = parseInt(key);
                    }
                    // 存储选中数据的标识对象
                    let checkList = [].concat(this.$data.checkList);
                    // 从数据源中删除指定数据
                    let value = _.difference(checkList[index], [key]);
                    checkList[index] = value;
                    this.$data.checkList = checkList;
                    // 模拟点击事件
                    let obj = {};
                    obj[this.foreignKey] = key;
                    this.checkboxChange(false, index, obj);
                },
                // 同步数据，返回给父组件
                syncData () {
                    let keys = this.selectKeys();
                    let value = this.selectValues(keys);
                    // 数据冒泡
                    this.$emit('update:keys', keys);
                    this.$emit('update:value', value);
                    this.$emit('change', {
                        keys: keys,
                        value: value
                    });
                },
                getList (query) {
                    return this.server.getSelectList(Object.assign({
                        name: this.name
                    }, query || {}));
                },
                getSelectListValue (index, value) {
                    const db = this.$data.list[index];
                    if (db) {
                        let where = {};
                        where[this.foreignAlias] = value;
                        var array = db.select(where);
                        return array;
                    }
                    return [];
                },
                // 获取数据
                getValue (index, value) {
                    let list = this.getSelectListValue(index, value);
                    return list;
                },
                // 获取 $data.list 数据
                getDB () {
                    return this.$data.list;
                },
                // 获取父级数据
                getParent: function(index, id) {
                    var self = this;
                    function prev(i, id) {
                        if (i >= 0) {
                            var db = self.$data.list[i];
                            // 查询子层数据所有列表
                            var where = {};
                            where[self.foreignKey] = id;
                            var item = db.selectOne(where);
                            if(item && item[self.foreignAlias]) {
                                var data = prev(i - 1, item[self.foreignAlias]);
                                return [].concat(item, data);
                            }
                            return [].concat(item);
                        }
                        return [];
                    }
                    var array = prev(index, id);
                    return array.reverse();
                },
                // 点击文本，展开子层列表
                checkboxClick (index, item) {
                    let array = [].concat(this.$data.showSelect);
                    array = array.slice(0, index + 1);
                    array[index + 1] = item[this.foreignKey];
                    this.$data.showSelect = array;
                },
                // 点击复选框
                checkboxChange (status, index, item) {
                    let indeterminate = this.$data.indeterminate;
                    // 存储选中数据的标识对象
                    let checkList = [].concat(this.$data.checkList);
                    // 取消自身半选样式
                    indeterminate[item[this.foreignKey]] = false;

                    // 设置选中状态
                    if(status) {
                        checkList[index] = _.uniq([].concat(checkList[index], item[this.foreignKey]));
                    } else {
                        checkList[index] = _.difference(checkList[index], [item[this.foreignKey]]);
                    }

                    let join_new = []; // 加入数据
                    let reduce_new = []; // 减少数据

                    // 处理子层状态
                    const next = (pId, i) => {
                        if (i >= this.$data.list.length) {
                            return false;
                        }
                        const db = this.$data.list[i];
                        // 获取子层列表数据
                        let obj = {};
                        obj[this.foreignAlias] = [].concat(pId);
                        let ids = db.select(obj).map(item => {
                            indeterminate[item[this.foreignKey]] = false;
                            return item[this.foreignKey];
                        });
                        if (status) {
                            // 合并两个数组
                            join_new[i] = [].concat(join_new[i] || [], ids);
                        } else {
                            reduce_new[i] = [].concat(reduce_new[i] || [], ids);
                        }
                        if (i + 1 < this.$data.list.length) {
                            // 递归处理子层的选中状态
                            next(ids, i + 1);
                        }
                    };

                    const prev = (id, i) => {
                        if (i < 0) {
                            return false;
                        }
                        const db = this.$data.list[i + 1];
                        // 查询子层数据所有列表
                        let obj = {};
                        obj[this.foreignAlias] = id;
                        const dataList = db.select(obj).map(value => value.id);
                        // 子层数据长度
                        let size = dataList.length;
                        // 求子层已选中的数据
                        let checkeds = _.intersection(checkList[i + 1], dataList).length;
                        let ids = [].concat(id);
                        // 假如选中的数据长度等于列表数据长度
                        if (size === checkeds) {
                            // 父级元素加入选中状态中
                            let value = _.compact([].concat(checkList[i] || [], ids));
                            // 去掉重复数据
                            checkList[i] = _.uniq(value);
                            indeterminate[id] = false; // 取消半选样式
                        } else {
                            // 父级元素删除选中状态中
                            let value = _.difference(checkList[i], ids);
                            checkList[i] = _.compact(value);
                            if (checkeds > 0) {
                                indeterminate[id] = true;
                            } else {
                                let status = false;
                                for (let i = 0; i < size; i++) {
                                    if (indeterminate[dataList[i]]) {
                                        status = true;
                                        break;
                                    }
                                }
                                indeterminate[id] = status;
                            }
                        }
                        // 如果当前层不是顶层
                        if (i - 1 >= 0) {
                            let number = i - 1;
                            // 向上冒泡 继续递归处理父层逻辑
                            const tmp = this.$data.list[i];
                            let _where = {};
                            _where[this.foreignKey] = id;
                            tmp.select(_where).forEach(value => prev(value[this.foreignAlias], number));
                        }
                    };
                    // 向上处理
                    prev(item[this.foreignAlias], index - 1);
                    // 向下处理
                    next(item[this.foreignKey], index + 1);
                    // 多段数据集合 一次处理
                    if (status) {
                        for(let i = 0, size = join_new.length; i < size; i++) {
                            // 合并两个数组
                            let value = [].concat(checkList[i] || [], join_new[i]);
                            // 去掉重复数据
                            checkList[i] = _.compact(_.uniq(value));
                        }
                    } else {
                        for(let i = 0, size = reduce_new.length; i < size; i++) {
                            // 去掉数组中部分元素
                            let value = _.difference(checkList[i], reduce_new[i]);
                            // 去掉重复数据
                            checkList[i] = _.compact(value);
                        }
                    }

                    // 维护数据状态
                    this.$data.checkList = checkList;
                    this.$data.indeterminate = indeterminate;
                    this.syncData();
                },
                // 筛选选中的元素 ID
                selectKeys () {
                    let array = [];
                    let exclude = {};
                    let checkList = this.$data.checkList;
                    const ignore = (index, id) => {
                        let value = _.compact([].concat(id));
                        if (id && value.length > 0) {
                            let db = this.$data.list[index];
                            if (db) {
                                let where = {};
                                where[this.foreignAlias] = value;
                                var keys = [];
                                db.select(where).forEach(value => {
                                    var _key = value[this.foreignKey];
                                    keys.push(_key);
                                    // 把子元素加入忽略对象中
                                    exclude[_key] = true;
                                });
                                ignore(index + 1, keys);
                            }
                        }
                    };
                    checkList.forEach((list, index) => {
                        array[index] = [];
                        let arr = [];
                        for (let i = 0, size = list.length; i < size; i++) {
                            let key = list[i];
                            // 如果存在，就跳过
                            if (exclude[key]) {
                                continue;
                            }
                            exclude[key] = true;
                            arr.push(key);
                        }
                        var keys = [];
                        for (let i = 0, size = arr.length; i < size; i++) {
                            let key = arr[i];
                            if (key) {
                                array[index].push(key);
                                keys.push(key);
                            }
                        }
                        ignore(index + 1, keys);
                    });
                    return array;
                },
                // 塞选选中元素的键值对数据
                selectValues (keys) {
                    let array = [];
                    if (!keys) {
                        keys = this.selectKeys();
                    }
                    for (let i = 0, size = keys.length; i < size; i++) {
                        const db = this.$data.list[i];
                        // 一次查询出多条数据集
                        let where = {};
                        where[this.foreignKey] = keys[i];
                        let data = db.select(where);
                        let map = {};
                        for (let j = 0, len = data.length; j < len; j++) {
                            let item = data[j];
                            map[item[this.foreignKey]] = item.name;
                        }
                        array[i] = map;
                    }
                    return array;
                },
                // 搜索框内容确认事件
                handleSearch (data) {
                    // 控制元素选中状态
                    if (data.id) {
                        let checkList = [].concat(this.$data.checkList);
                        // 设置为选中状态
                        checkList[data.index] = _.uniq([].concat(checkList[data.index], data[this.foreignKey]));
                        this.$data.checkList = checkList;

                        if (this.onPage) {
                            let tmp0 = {};
                            tmp0[this.foreignKey] = data.rId;
                            this.checkboxClick(0, tmp0); // 控制第二层展开
                            let tmp1 = {};
                            tmp1[this.foreignKey] = data[this.foreignAlias];
                            this.checkboxClick(1, tmp1, [data[this.foreignKey]]); // 控制第三层展开
                        } else {
                            // 模拟点击复选框事件
                            this.checkboxChange(true, data.index, data);
                        }

                    }
                },
                // 列出搜索内容
                async searchQuery (queryString, cb) {
                    queryString = (queryString || '');
                    if (!queryString) {
                        return cb([]);
                    }
                    if (this.onPage) {
                        let query = {
                            searchVal: queryString,
                            name: this.name
                        };
                        let value = [];
                        try {
                            let list = await this.server.getSearchValue(query);
                            value = list.map(item => {
                                return {
                                    value: item.name,
                                    id: item[this.foreignKey],
                                    pId: item[this.foreignAlias],
                                    rId: item['rootId'],
                                    index: this.$data.list.length - 1
                                };
                            });
                        } catch (e) {
                            value = [];
                        }
                        cb(value);
                    } else {
                        let value = [];
                        let list = this.$data.list;
                        for (let i = 0, size = list.length; i < size; i++) {
                            const db = list[i];
                            let result = db.like({ name: queryString });
                            result.forEach(item => {
                                value.push({
                                    index: i,
                                    value: item.name,
                                    id: item[this.foreignKey],
                                    pId: item[this.foreignAlias],
                                });
                            });
                        }
                        cb(value);
                    }
                }
            },
        };
    }
    return App();
});
